package clases;

import java.util.ArrayList;

import etiquietas.Fabricante;

public class Equipo {
	private String nombre;
	private Fabricante fabricante;
	private byte nMecanicos;
	private ArrayList<Piloto>pilotos;
	
	public Equipo(String nombre, Fabricante fabricante, byte nMecanicos, ArrayList<Piloto> pilotos) {
		super();
		this.nombre = nombre;
		this.fabricante = fabricante;
		this.nMecanicos = nMecanicos;
		this.pilotos = pilotos;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Fabricante getFabricante() {
		return fabricante;
	}

	public void setFabricante(Fabricante fabricante) {
		this.fabricante = fabricante;
	}

	public byte getnMecanicos() {
		return nMecanicos;
	}

	public void setnMecanicos(byte nMecanicos) {
		this.nMecanicos = nMecanicos;
	}

	public ArrayList<Piloto> getPilotos() {
		return pilotos;
	}

	public void setPilotos(ArrayList<Piloto> pilotos) {
		this.pilotos = pilotos;
	}

	@Override
	public String toString() {
		return "\n\t>"+this.nombre + " " + this.fabricante + "\n\t\tMecanicos= " + this.nMecanicos + "\n\t\tPilotos= "+ this.pilotos ;
	}
	
}
