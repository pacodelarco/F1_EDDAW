package mainApuntes;

import clases.Piloto;
import etiquietas.Fabricante;
import clases.Equipo;

import java.util.ArrayList;


import clases.Competicion;

public class Principal {

	public static void main(String[] args) {
		ArrayList<Piloto>pilotosAsus=new ArrayList<Piloto>();
		Piloto pacoDelArco = new Piloto("Paco", "Del Arco", (byte)18);
		Piloto auroraAznar = new Piloto("Aurora", "Aznar", (byte)20);
		pilotosAsus.add(pacoDelArco);
		pilotosAsus.add(auroraAznar);
		
		ArrayList<Piloto>pilotosPhilips=new ArrayList<Piloto>();
		Piloto juanCastilla = new Piloto("Juan", "Castilla", (byte)20);
		Piloto manuelPorras = new Piloto("Manuel", "Porras", (byte)25);
		pilotosPhilips.add(juanCastilla);
		pilotosPhilips.add(manuelPorras);
		
		ArrayList<Equipo>equipos=new ArrayList<Equipo>();
		Equipo asusHonda =new Equipo("Asus",Fabricante.HONDA , (byte) 57, pilotosAsus);
		Equipo philipsMercedes =new Equipo("Philips",Fabricante.MERCEDES , (byte) 104, pilotosPhilips);
		equipos.add(asusHonda);		
		equipos.add(philipsMercedes);
		
		
		ArrayList<Competicion>competicion=new ArrayList<Competicion>();
		Competicion f1 = new Competicion("F1", equipos);
		competicion.add(f1);
		
		System.out.println(competicion);
		
	}

}
