 package etiquietas;

public enum Fabricante {
	FERRARI,
	MERCEDES,
	HONDA,
	MCLAREN,
	RENAULT,
}
